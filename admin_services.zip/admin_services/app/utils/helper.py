# Placeholder for helper functions
def say_hello(name):
    return f"Hello, {name}"
